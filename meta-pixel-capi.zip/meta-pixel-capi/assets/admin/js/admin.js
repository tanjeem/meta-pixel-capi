jQuery(document).ready(function($) {

	// ── Tab Switching ──
	$('.mpc-tab-btn').on('click', function() {
		var tab = $(this).data('tab');
		$('.mpc-tab-btn').removeClass('active');
		$(this).addClass('active');
		$('.mpc-tab-panel').removeClass('active');
		$('.mpc-tab-panel[data-panel="' + tab + '"]').addClass('active');
		
		if (tab === 'logs') {
			mpc_fetch_logs();
		}
	});

	// ── Log filtering by platform ──
	var mpcLogFilter = 'all';
	function mpc_apply_log_filter() {
		$('#mpc-log-body tr').each(function() {
			var t = $(this).data('type');
			if (mpcLogFilter === 'all' || t === undefined || t === mpcLogFilter) {
				$(this).show();
			} else {
				$(this).hide();
			}
		});
	}
	$(document).on('click', '.mpc-filter-pill[data-filter]', function() {
		$('.mpc-filter-pill[data-filter]').removeClass('active');
		$(this).addClass('active');
		mpcLogFilter = $(this).data('filter');
		mpc_apply_log_filter();
	});

	// ── Purchase Send Audit ──
	var mpcAuditDays = 14;
	function mpc_fetch_audit() {
		$.post(ajaxurl, {
			action: 'mpc_purchase_audit',
			days: mpcAuditDays,
			mpc_nonce: $('#mpc-settings-form input[name="mpc_nonce"]').val()
		}, function(res) {
			if (!res.success) { return; }
			$('#mpc-audit-body').html(res.data.html);
			var d = res.data;
			var msg;
			if (d.orders === 0) {
				msg = 'No Purchase events logged in the last ' + d.days + ' days.';
			} else if (d.duplicated === 0) {
				msg = '<strong>' + d.orders + '</strong> orders, <strong>' + d.total + '</strong> Purchase events sent — no duplicates. '
				    + 'If Meta reports more conversions than you have orders, the cause is outside this plugin.';
			} else {
				msg = '<strong style="color:#c00;">' + d.duplicated + ' of ' + d.orders + ' orders were sent more than once.</strong> '
				    + d.total + ' Purchase events for ' + d.orders + ' orders in the last ' + d.days + ' days.';
			}
			$('#mpc-audit-summary').html(msg);
		});
	}
	$(document).on('click', '#mpc-conflict-scan', function() {
		var $btn = $(this), $out = $('#mpc-conflict-results');
		$btn.prop('disabled', true);
		$out.html('<p style="color:var(--mpc-text-dim);">Scanning active plugins and fetching your site HTML…</p>');
		$.post(ajaxurl, {
			action: 'mpc_conflict_scan',
			mpc_nonce: $('#mpc-settings-form input[name="mpc_nonce"]').val()
		}, function(res) {
			$btn.prop('disabled', false);
			if (!res.success) { $out.html('<p style="color:var(--mpc-danger);">Scan failed.</p>'); return; }
			var d = res.data, html = '';
			if (d.clean) {
				html += '<p style="color:var(--mpc-success);"><strong>No other Meta sender found on this site.</strong> '
				      + 'If Meta still reports more conversions than the audit below, the source is outside this site — '
				      + 'a staging copy using the same Pixel ID, or a partner/CAPI Gateway integration on the dataset.</p>';
			} else {
				html += '<ul style="margin:0 0 12px; padding-left:18px;">';
				d.warnings.forEach(function(w) { html += '<li style="color:var(--mpc-danger); margin-bottom:6px;">' + w + '</li>'; });
				html += '</ul>';
			}
			if (d.notes.length) {
				html += '<ul style="margin:0; padding-left:18px; color:var(--mpc-text-muted);">';
				d.notes.forEach(function(n) { html += '<li style="margin-bottom:4px;">' + n + '</li>'; });
				html += '</ul>';
			}
			$out.html(html);
		});
	});

	$(document).on('click', '#mpc-export-diagnostics', function() {
		var nonce = $('#mpc-settings-form input[name="mpc_nonce"]').val();
		window.location = ajaxurl + '?action=mpc_export_diagnostics'
			+ '&days=' + encodeURIComponent(mpcAuditDays)
			+ '&mpc_nonce=' + encodeURIComponent(nonce);
	});

	$(document).on('click', '[data-audit-days]', function() {
		$('[data-audit-days]').removeClass('active');
		$(this).addClass('active');
		mpcAuditDays = $(this).data('audit-days');
		mpc_fetch_audit();
	});
	mpc_fetch_audit();

	// ── Auto-Refresh Event Logs ──
	function mpc_fetch_logs() {
		$.post(ajaxurl, {
			action: 'mpc_fetch_logs_html',
			mpc_nonce: $('#mpc-settings-form input[name="mpc_nonce"]').val()
		}, function(res) {
			if (res.success && res.data.html) {
				$('#mpc-log-body').html(res.data.html);
				mpc_apply_log_filter();
			}
		});
	}
	
	// Initial fetch and poll every 10 seconds
	mpc_fetch_logs();
	setInterval(function() {
		if ($('.mpc-tab-panel[data-panel="logs"]').hasClass('active')) {
			mpc_fetch_logs();
		}
	}, 10000);

	// ── AJAX Save ──
	$('#mpc-settings-form').on('submit', function(e) {
		e.preventDefault();
		var $btn = $('#mpc-save-btn');
		var $msg = $('#mpc-save-msg');
		$btn.text('Saving...').prop('disabled', true);

		$.ajax({
			url: ajaxurl,
			method: 'POST',
			data: $(this).serialize() + '&action=mpc_save_settings',
			success: function(res) {
				if (res.success) {
					$msg.addClass('visible').text('✓ ' + res.data.message);
					setTimeout(function() { $msg.removeClass('visible'); }, 3000);
				} else {
					$msg.addClass('visible').css('color', '#ef4444').text('✗ Save failed.');
					setTimeout(function() { $msg.removeClass('visible').css('color', ''); }, 3000);
				}
			},
			error: function() {
				$msg.addClass('visible').css('color', '#ef4444').text('✗ Network error.');
				setTimeout(function() { $msg.removeClass('visible').css('color', ''); }, 3000);
			},
			complete: function() {
				$btn.text('Save Configuration').prop('disabled', false);
			}
		});
	});

	// ── Copy to Clipboard ──
	$('.mpc-copy-box').on('click', function() {
		var text = $(this).data('copy');
		var $icon = $(this).find('.dashicons');
		navigator.clipboard.writeText(text).then(function() {
			$icon.removeClass('dashicons-admin-page').addClass('dashicons-yes-alt').css('color', '#22c55e');
			setTimeout(function() {
				$icon.removeClass('dashicons-yes-alt').addClass('dashicons-admin-page').css('color', '');
			}, 2000);
		});
	});

	// ── Retry Queue ──
	$('#mpc-retry-now').on('click', function() {
		var $msg = $('#mpc-debug-msg');
		$(this).text('Retrying...').prop('disabled', true);
		$.post(ajaxurl, {
			action: 'mpc_retry_queue',
			mpc_nonce: $('#mpc-settings-form input[name="mpc_nonce"]').val()
		}, function(res) {
			$msg.text(res.data ? res.data.message : 'Done!');
			$('#mpc-retry-now').text('Retry Failed Events').prop('disabled', false);
		});
	});

	// ── Token Test ──
	$('#mpc-test-token').on('click', function() {
		var $btn = $(this);
		var $res = $('#mpc-token-test-result');
		var token = $('#mpc_capi_token').val();
		var pixel_id = $('#mpc_pixel_id').val();
		
		if (!token || !pixel_id) {
			$res.css('color', '#ef4444').text('✗ Please enter both Pixel ID and Access Token first.');
			return;
		}

		$btn.text('Testing...').prop('disabled', true);
		$res.text('').css('color', '');

		$.post(ajaxurl, {
			action: 'mpc_test_token',
			mpc_nonce: $('#mpc-settings-form input[name="mpc_nonce"]').val(),
			pixel_id: pixel_id,
			token: token
		}, function(res) {
			$btn.text('Test Token Connection').prop('disabled', false);
			if (res.success) {
				$res.css('color', '#22c55e').html('✓ <strong>Success:</strong> Connected to pixel "' + res.data.name + '" (Created: ' + res.data.creation_time + ')');
			} else {
				$res.css('color', '#ef4444').html('✗ <strong>Error:</strong> ' + res.data.message);
			}
		}).fail(function() {
			$btn.text('Test Token Connection').prop('disabled', false);
			$res.css('color', '#ef4444').text('✗ Network error.');
		});
	});

	// ── Clear Logs ──
	$('#mpc-clear-logs').on('click', function() {
		if (!confirm('Are you sure you want to delete all event logs?')) return;
		var $msg = $('#mpc-debug-msg');
		$(this).text('Clearing...').prop('disabled', true);
		$.post(ajaxurl, {
			action: 'mpc_clear_logs',
			mpc_nonce: $('#mpc-settings-form input[name="mpc_nonce"]').val()
		}, function(res) {
			$msg.text(res.data ? res.data.message : 'Logs cleared!');
			$('#mpc-log-body').html('<tr><td colspan="5" style="text-align:center; color: #64748b; padding: 30px;">Logs cleared.</td></tr>');
			$('#mpc-clear-logs').text('Clear All Logs').prop('disabled', false);
		});
	});
});
